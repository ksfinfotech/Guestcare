# GuestCare – Foreign Patient Hospitality Desk (Next.js, Vercel-ready)

## Run
    npm install && npm run dev        # http://localhost:3000
    Deploy: push to GitHub -> Import in Vercel. Set CRON_SECRET, STAFF_EMAIL.

## Architecture
- Next.js App Router. UI = app/page.js (client). API = app/api/* route handlers.
- lib/visa.js: visa pipeline, days-left math, EFRRO simulation, alert generator (pure, unit-testable).
- lib/db.js: in-memory demo store. REPLACE with Postgres + Prisma before real use.
- vercel.json: daily cron -> /api/cron/visa-alerts -> creates alerts 15 days before expiry (deduped) for staff AND patient.

## Data model (tables in production)
patients(id, name, nationality, passport, email, phone, hospital_ref, status, check_in, check_out, flat_id)
visas(patient_id, type, step, expiry, efrro_ref) + visa_events(patient_id, step, at, note)
flats(id, label, capacity, status)   services(id, patient_id, type, detail, active, price)
notifications(id, key UNIQUE, patient_id, audience, to, channel, message, sent_at)

## Production checklist
1. Auth + roles (NextAuth: admin / front-desk / read-only). Every API route is currently open.
2. Real DB; encrypt passport numbers; audit log of edits (medical/immigration data is sensitive: follow local privacy law).
3. Email/SMS: replace console.log in lib/visa.js (Resend, Twilio/WhatsApp). Send patient alerts in their language.
4. EFRRO: simulateEfrroAdvance is a stub. Use official/authorised channels only; many steps stay manual (staff enter the reference number).
5. Also alert at 7 days and 1 day (call runVisaAlerts with different windows and a different key suffix).

## Add-on ideas
Flat availability calendar + housekeeping status; meal planner with dietary/religious needs; airport pickup + vehicle scheduling;
interpreter roster; document vault (passport, visa, invitation letter) with expiry OCR; WhatsApp patient chatbot;
FRRO Form-C/arrival compliance checklist; billing for hospitality services; caregiver/attendant visas; feedback survey at checkout;
multilingual patient portal; occupancy/visa-risk analytics dashboard.
