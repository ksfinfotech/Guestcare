import { db } from '../../../../lib/db';
import { runVisaAlerts } from '../../../../lib/visa';

export const dynamic = 'force-dynamic';
// Called daily by Vercel Cron (see vercel.json). Rejects anyone without the secret.
export function GET(req) {
  if (process.env.CRON_SECRET && req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`)
    return new Response('Unauthorized', { status: 401 });
  return Response.json({ sent: runVisaAlerts(db, 15).length });
}
