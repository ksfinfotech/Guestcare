import { db } from '../../../lib/db';
import { simulateEfrroAdvance } from '../../../lib/visa';

export const dynamic = 'force-dynamic';
export const GET = () => Response.json(db.patients);

// Create a patient (usually an upcoming one)
export async function POST(req) {
  const b = await req.json();
  const p = {
    id: Date.now(), status: 'UPCOMING', flat: null, services: [], hospitalRef: b.hospitalRef || '',
    passport: b.passport || '', phone: b.phone || '', name: b.name, nationality: b.nationality, email: b.email,
    checkIn: b.checkIn, checkOut: b.checkOut || null,
    visa: { type: 'MEDICAL', step: 'INVITATION_LETTER', expiry: b.visaExpiry || null, efrroRef: null, history: [] },
  };
  db.patients.push(p);
  return Response.json(p, { status: 201 });
}

// One endpoint, several actions. Add auth (e.g. NextAuth role check) before going live.
export async function PATCH(req) {
  const { id, action, ...d } = await req.json();
  const p = db.patients.find((x) => x.id === id);
  if (!p) return Response.json({ error: 'Not found' }, { status: 404 });

  if (action === 'advanceVisa') simulateEfrroAdvance(p.visa);
  else if (action === 'addService') p.services.push({ id: crypto.randomUUID(), active: true, type: d.type, detail: d.detail });
  else if (action === 'toggleService') { const s = p.services.find((x) => x.id === d.serviceId); if (s) s.active = !s.active; }
  else if (action === 'checkIn') { p.status = 'IN_HOUSE'; p.checkIn = d.date || p.checkIn; }
  else if (action === 'checkOut') { p.status = 'CHECKED_OUT'; p.checkOut = d.date || p.checkOut; }
  else {
    // plain field edits: checkIn, checkOut, flat, visaExpiry
    for (const k of ['checkIn', 'checkOut', 'flat']) if (k in d) p[k] = d[k] || null;
    if ('visaExpiry' in d) p.visa.expiry = d.visaExpiry || null;
  }
  return Response.json(p);
}
