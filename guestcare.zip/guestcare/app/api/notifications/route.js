import { db } from '../../../lib/db';
import { runVisaAlerts } from '../../../lib/visa';

export const dynamic = 'force-dynamic';
export const GET = () => Response.json(db.notifications);
// Manual "run check now" button for staff
export const POST = () => Response.json(runVisaAlerts(db, 15));
