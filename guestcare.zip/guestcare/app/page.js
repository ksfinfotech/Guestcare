'use client';
import { useEffect, useState } from 'react';
import { VISA_STEPS, daysLeft } from '../lib/visa';

const SERVICE_TYPES = ['FLAT', 'MEALS', 'TRANSPORT', 'INTERPRETER', 'SIM_CARD', 'OTHER'];
const call = (method, body) => fetch('/api/patients', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

export default function Desk() {
  const [patients, setPatients] = useState([]);
  const [notes, setNotes] = useState([]);
  const [tab, setTab] = useState('IN_HOUSE');
  const [form, setForm] = useState({ name: '', nationality: '', email: '', checkIn: '', visaExpiry: '' });

  const load = async () => {
    setPatients(await (await fetch('/api/patients')).json());
    setNotes(await (await fetch('/api/notifications')).json());
  };
  useEffect(() => { load(); }, []);
  const act = async (id, body) => { await call('PATCH', { id, ...body }); load(); };

  const expiring = patients.filter((p) => p.status !== 'CHECKED_OUT' && daysLeft(p.visa.expiry) !== null && daysLeft(p.visa.expiry) <= 15);
  const list = patients.filter((p) => p.status === tab);

  // Colour-coded visa badge: red <=7 days, amber <=15 days
  const badge = (d) => d === null ? <span className="pill">No expiry set</span>
    : <span className={'pill ' + (d <= 7 ? 'bad' : d <= 15 ? 'warn' : '')}>Visa: {d < 0 ? 'expired' : d + ' days left'}</span>;

  return (
    <main>
      <h1>Foreign patient desk</h1>
      <div className="stats">
        <div className="stat"><b>{patients.filter((p) => p.status === 'IN_HOUSE').length}</b>In house</div>
        <div className="stat"><b>{patients.filter((p) => p.status === 'UPCOMING').length}</b>Arriving</div>
        <div className="stat"><b>{expiring.length}</b>Visa ≤ 15 days</div>
      </div>

      <div className="tabs">
        {[['IN_HOUSE', 'In house'], ['UPCOMING', 'Upcoming'], ['CHECKED_OUT', 'Checked out'], ['ALERTS', 'Alerts']].map(([k, l]) =>
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}
      </div>

      {tab === 'UPCOMING' && (
        <div className="card row">
          {/* Quick add for a new incoming patient */}
          {['name', 'nationality', 'email'].map((k) => <input key={k} placeholder={k} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />)}
          <label className="mute">Arrival <input type="date" value={form.checkIn} onChange={(e) => setForm({ ...form, checkIn: e.target.value })} /></label>
          <label className="mute">Visa expiry <input type="date" value={form.visaExpiry} onChange={(e) => setForm({ ...form, visaExpiry: e.target.value })} /></label>
          <button className="primary" disabled={!form.name || !form.checkIn} onClick={async () => { await call('POST', form); setForm({ name: '', nationality: '', email: '', checkIn: '', visaExpiry: '' }); load(); }}>Add patient</button>
        </div>
      )}

      {tab === 'ALERTS' ? (
        <>
          <button className="primary" onClick={async () => { await fetch('/api/notifications', { method: 'POST' }); load(); }}>Run visa check now</button>
          {notes.length === 0 && <p className="mute">No alerts sent yet. Run the check to see any visas expiring within 15 days.</p>}
          {notes.map((n) => (
            <div className="card" key={n.id}>
              <div className="row"><span className="pill">{n.audience === 'STAFF' ? 'To staff' : 'To patient'}</span><span className="mute">{n.to} · {new Date(n.sentAt).toLocaleString()}</span></div>
              <p>{n.message}</p>
            </div>
          ))}
        </>
      ) : (
        <>
          {list.length === 0 && <p className="mute">No patients in this list.</p>}
          {list.map((p) => {
            const stepIdx = VISA_STEPS.findIndex((s) => s.key === p.visa.step);
            return (
              <div className="card" key={p.id}>
                <div className="row"><strong>{p.name}</strong><span className="mute">{p.nationality} · {p.hospitalRef}</span>{badge(daysLeft(p.visa.expiry))}</div>

                {/* Stay details: editable dates and flat */}
                <div className="row" style={{ marginTop: 8 }}>
                  <label className="mute">Check-in <input type="date" value={p.checkIn || ''} onChange={(e) => act(p.id, { checkIn: e.target.value })} /></label>
                  <label className="mute">Check-out <input type="date" value={p.checkOut || ''} onChange={(e) => act(p.id, { checkOut: e.target.value })} /></label>
                  <label className="mute">Flat <input style={{ width: 90 }} defaultValue={p.flat || ''} placeholder="Assign" onBlur={(e) => e.target.value !== (p.flat || '') && act(p.id, { flat: e.target.value })} /></label>
                  <label className="mute">Visa expiry <input type="date" value={p.visa.expiry || ''} onChange={(e) => act(p.id, { visaExpiry: e.target.value })} /></label>
                </div>

                {/* Visa progress */}
                <div className="steps" aria-label="Visa progress">{VISA_STEPS.slice(0, 5).map((s, i) => <i key={s.key} className={i <= stepIdx ? 'done' : ''} />)}</div>
                <div className="row"><span className="mute">{VISA_STEPS[stepIdx].label}{p.visa.efrroRef ? ` · ${p.visa.efrroRef}` : ''}</span>
                  <button onClick={() => act(p.id, { action: 'advanceVisa' })}>Simulate next step</button></div>

                {/* Hospitality services */}
                <div className="row" style={{ marginTop: 8 }}>
                  {p.services.map((s) => <button key={s.id} className={'pill ' + (s.active ? 'on' : '')} onClick={() => act(p.id, { action: 'toggleService', serviceId: s.id })}>{s.type}: {s.detail}</button>)}
                  <select defaultValue="" onChange={(e) => { const t = e.target.value; if (!t) return; const detail = prompt(`Details for ${t}`) || ''; act(p.id, { action: 'addService', type: t, detail }); e.target.value = ''; }}>
                    <option value="">+ Add service</option>{SERVICE_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>

                <div className="row" style={{ marginTop: 8 }}>
                  {p.status === 'UPCOMING' && <button className="primary" onClick={() => act(p.id, { action: 'checkIn' })}>Check in today</button>}
                  {p.status === 'IN_HOUSE' && <button onClick={() => act(p.id, { action: 'checkOut' })}>Check out</button>}
                </div>
              </div>
            );
          })}
        </>
      )}
    </main>
  );
}
